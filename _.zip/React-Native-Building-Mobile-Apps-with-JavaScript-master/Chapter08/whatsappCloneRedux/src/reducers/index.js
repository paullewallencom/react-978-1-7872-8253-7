import { combineReducers } from 'redux';
import messages from './messagesReducer';

export default messages;
