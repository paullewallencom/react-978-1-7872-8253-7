import { StackNavigator } from 'react-navigation';
import routes from './config/routes';

export default StackNavigator(routes);