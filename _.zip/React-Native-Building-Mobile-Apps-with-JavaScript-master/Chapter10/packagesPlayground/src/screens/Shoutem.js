import React from 'react';
import { Examples } from '@shoutem/ui';

export default Shoutem = () => (
    <Examples />
)

Shoutem.navigationOptions = ({ navigation }) => ({
    title: "Shoutem playground"
})