import React from 'react';
import { View, Text } from 'react-native';

export const VideoList = () => (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
    <Text>VideoList</Text>
  </View>
)
